.. geni-lib documentation master file, created by
   sphinx-quickstart on Sat Aug 23 13:28:29 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to geni-lib's documentation!
====================================

Contents:

.. toctree::
   :maxdepth: 2

   intro/intro
   intro/credentials
   intro/install
   intro/config

   tutorials/index

   api/api

   dev/index

Indices and tables
==================
  * :ref:`modindex`
  * :ref:`search`

