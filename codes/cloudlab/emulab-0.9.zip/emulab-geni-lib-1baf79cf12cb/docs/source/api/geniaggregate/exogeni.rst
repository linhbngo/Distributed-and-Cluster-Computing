geni.aggregate.exogeni
======================

.. automodule:: geni.aggregate.exogeni
  :undoc-members:
  :inherited-members:
  :members:

