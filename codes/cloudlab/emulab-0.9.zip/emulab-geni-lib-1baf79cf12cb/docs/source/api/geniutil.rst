geni.util
=========

.. automodule:: geni.util
  :undoc-members:
  :members:

