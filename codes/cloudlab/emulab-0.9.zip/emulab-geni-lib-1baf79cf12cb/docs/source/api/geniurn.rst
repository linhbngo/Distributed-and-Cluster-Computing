geni.urn
=========

.. automodule:: geni.urn
  :members:
  :special-members:
  :exclude-members: __weakref__
