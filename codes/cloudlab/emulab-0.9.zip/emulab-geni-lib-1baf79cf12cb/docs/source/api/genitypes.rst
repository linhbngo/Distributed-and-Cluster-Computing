geni.types
==========

.. automodule:: geni.types
  :undoc-members:
  :members:
