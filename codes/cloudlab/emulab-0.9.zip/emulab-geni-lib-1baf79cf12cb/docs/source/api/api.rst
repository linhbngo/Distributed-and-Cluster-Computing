API
===

.. toctree::
   geniaggregate/index
   geniminigcfconfig
   geniportal
   genirspec/index
   genitypes
   geniurn
   geniutil
