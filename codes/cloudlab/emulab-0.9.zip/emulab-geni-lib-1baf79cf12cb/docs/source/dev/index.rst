.. Copyright (c) 2017  Barnstormer Softworks, Ltd.

.. raw:: latex

  \newpage


Development
===========

This section of the documentation is for people wishing to contribute to the ``geni-lib`` project, or at least
hoping to gain further insight into the existing code internals.  This documentation is even less complete
than the other sections, but hopefully will be useful.

.. toctree::
  usecasenotes
  codingstandards
