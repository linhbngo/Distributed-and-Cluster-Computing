Installation
============

.. toctree::
   ubuntu
   ubuntu16
   macosx
   vagrant
